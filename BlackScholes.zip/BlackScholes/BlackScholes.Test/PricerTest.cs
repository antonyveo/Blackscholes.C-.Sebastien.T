﻿using System;
using NUnit.Framework;

namespace BlackScholes.Test
{
    public class PricerTest
    {
        [TestCase(50, 55, 1, 0.2, 0.09, 0.0734)]
        [TestCase(64, 60, 180 / 365d, 0.27, 0.045, 0.5522)]
        public void D1ShouldBe(double stock, double strike, double time, double volatility, double rate, double expectedD1)
        {
            var pricer = new Pricer();
            var (d1, _, _, _) = pricer.Compute(stock, strike, time, volatility, rate);
            Assert.AreEqual(expectedD1, Math.Round(d1, 4), "Wrong d1");
        }

        [TestCase(50, 55, 1, 0.2, 0.09, -0.1266)]
        [TestCase(64, 60, 180 / 365d, 0.27, 0.045, 0.3626)]
        public void D2ShouldBe(double stock, double strike, double time, double volatility, double rate, double expectedD2)
        {
            var pricer = new Pricer();
            var (_, d2, _, _) = pricer.Compute(stock, strike, time, volatility, rate);
            Assert.AreEqual(expectedD2, Math.Round(d2, 4), "Wrong d2");
        }

        [TestCase(50, 55, 1, 0.2, 0.09, 3.8617)]
        [TestCase(64, 60, 180 / 365d, 0.27, 0.045, 7.7661)]
        public void CallShouldBe(double stock, double strike, double time, double volatility, double rate, double expectedCall)
        {
            var pricer = new Pricer();
            var (_, _, call, _) = pricer.Compute(stock, strike, time, volatility, rate);
            Assert.AreEqual(expectedCall, Math.Round(call, 4), "Wrong Call");
        }

        [TestCase(50, 55, 1, 0.2, 0.09, 4.1279)]
        [TestCase(64, 60, 180 / 365d, 0.27, 0.045, 2.4493)]
        public void PutShouldBe(double stock, double strike, double time, double volatility, double rate, double expectedPut)
        {
            var pricer = new Pricer();
            var (_, _, _, put) = pricer.Compute(stock, strike, time, volatility, rate);
            Assert.AreEqual(expectedPut, Math.Round(put, 4), "Wrong Put");
        }
    }
}
