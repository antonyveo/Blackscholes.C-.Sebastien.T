﻿using System.Windows;

namespace BlackScholes
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new BlackScholesModel
            {
                Stock = 50,
                Strike = 55,
                Time = 1,
                Volatility = 0.2,
                Rate = 0.09
            };
        }
    }
}
