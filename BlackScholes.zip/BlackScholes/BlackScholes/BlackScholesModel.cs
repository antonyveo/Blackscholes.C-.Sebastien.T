﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace BlackScholes
{
    public class BlackScholesModel : INotifyPropertyChanged
    {
        private readonly Pricer _pricer;
        private double _stock;
        private double _strike;
        private double _time;
        private double _volatility;
        private double _rate;
        private double _d1;
        private double _d2;
        private double _call;
        private double _put;

        public double Stock
        {
            get => _stock;
            set
            {
                _stock = value;
                Compute();
            }
        }

        public double Strike
        {
            get => _strike;
            set
            {
                _strike = value;
                Compute();
            }
        }

        public double Time
        {
            get => _time;
            set
            {
                _time = value;
                Compute();
            }
        }

        public double Volatility
        {
            get => _volatility;
            set
            {
                _volatility = value;
                Compute();
            }
        }

        public double Rate
        {
            get => _rate;
            set
            {
                _rate = value;
                Compute();
            }
        }

        public double D1
        {
            get => _d1;
            set
            {
                _d1 = value;
                OnPropertyChanged();
            }
        }

        public double D2
        {
            get => _d2;
            set
            {
                _d2 = value;
                OnPropertyChanged();
            }
        }

        public double Call
        {
            get => _call;
            set
            {
                _call = value;
                OnPropertyChanged();
            }
        }

        public double Put
        {
            get => _put;
            set
            {
                _put = value;
                OnPropertyChanged();
            }
        }

        public BlackScholesModel()
        {
            _pricer = new Pricer();
        }

        private void Compute()
        {
            (D1, D2, Call, Put) = _pricer.Compute(Stock, Strike, Time, Volatility, Rate);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}